import os
os.system("cls")

deposit = int(input("Deposit:"))
foyiz = 24
yil = int(input("Yil:"))

summa = deposit + deposit * foyiz / 100 * yil

print(int(summa))