import os
os.system("cls")

users = [
    'Abdulla Abdullaev', 
    'Samandar Asadov', 
    'Shaxnoza Jurayeva', 
    'Ikrom Karimov',
    'Gulnora Xalilova',
    'Ziyoda Yuldashova'
]

men = []
women = []

for i in users:
    familiya = i.split()[-1]

    if familiya[-2:] == "ov" or familiya[-2:] == "ev":
        men.append(i)
    elif familiya[-2:] == "va":
        women.append(i)
print(men)
print(women)